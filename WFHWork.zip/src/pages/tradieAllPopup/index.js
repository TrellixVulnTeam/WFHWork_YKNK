import React from 'react';
import Pop1 from './pop1';

const Index = () => {
	return (
		<div className="Tradie-all-Popup">
			<Pop1 />
		</div>
	);
};
export default Index;
